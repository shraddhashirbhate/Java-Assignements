import java.util.Scanner;
class Que15{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Name : ");
		String Name = sc.nextLine();
		
		System.out.println("Enter Gender : ");
		char Gender = sc.next().charAt(0);
		//System.out.println(g);	

		System.out.println("Enter Age : ");
		int age = sc.nextInt();

		if (Gender=='m' || Gender=='M' && age >= 21)
			System.out.println(Name + " is Eligible for Marriage");
		else if (Gender=='f' || Gender=='F' && age >= 18)
			System.out.println(Name + " is Eligible forMarriage");
		else
			System.out.println(Name + " is not Eligible for Marriage");
	}

}