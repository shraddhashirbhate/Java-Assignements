import java.util.Scanner;
class Que8{
	public static void main(String srgs[]) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Principle Amount : ");
		float P = sc.nextFloat();

		System.out.println("Enter Rate of Interest : ");
		float R = sc.nextFloat();

		System.out.println("Enter time : ");
		float T = sc.nextInt();
		
		double SI = P*R*T / 100;
		System.out.println("Simple Interest : " +SI);
	}
	
}