import java.util.Scanner;
class Que12{
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Basic Salary : ");
		float BS = sc.nextFloat();
		float HRA;
		float DA;
		float Gross;
 
		if( BS < 10000)
		{
			HRA = (float)0.1*BS;	
			DA = (float)0.9*BS;
		}
		 else 
		{
			HRA = 2000;
			DA = (float)0.98*BS;		
		}

		Gross = BS + DA + HRA;
		System.out.println("Gross Salary is  :  " +Gross);
		
		
	}

}