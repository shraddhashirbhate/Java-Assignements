import java.util.Scanner;
class Que7{
	public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter marks of student in 5 subjects : ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		int d = sc.nextInt();
		int e = sc.nextInt();
	int sum = a+b+c+d+e;
	System.out.println("Sum = " +sum);
	double per = sum*100/500;
	System.out.println("Percentage Marks = " +per + "%");
	}
}