class Que2{
	public static void main(String args[]){
		int roll_no = 100;
		System.out.println("ROll_No = " +roll_no);
	}

}