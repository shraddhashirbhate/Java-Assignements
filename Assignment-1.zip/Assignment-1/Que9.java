import java.util.Scanner;
class Que9{
	public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of days : ");
		int days = sc.nextInt();
		int years = days/365;
		System.out.println("Years = " +years);

		int remainder1 = days%365;
		int month = remainder1/30;
		System.out.println("Months = " +month);

		int days1 = remainder1%30;
		System.out.println("Days = " +days1);

		
	}
}