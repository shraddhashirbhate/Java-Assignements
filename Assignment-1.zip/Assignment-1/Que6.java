import java.util.Scanner;
class Que6{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the radius of circle : ");
		float radius = sc.nextFloat();
		double cal =  2*3.14*radius;
		float circum = (float)cal;
		double a = 3.14*radius*radius;
		float area = (float)a;
	
		System.out.println("Circumference of Circle is : " +circum);
		System.out.println("Area of Circle is : " +area);	
	
	}

}