import java.util.Scanner;
class Que13{
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st number :  ");
		int a = sc.nextInt();
		
		System.out.println("Enter 2nd number :  ");
		int b = sc.nextInt();
		
		System.out.println("Enter 3rd number :  ");
		int c = sc.nextInt();

		/* Using If-else */

		if (a>b && a>c)
			System.out.println(a + " is greater than " +b + " and " +c);
		else if (b>a && b>c)
			System.out.println(b + " is greater than " +a  +" and " +c);
		else
			System.out.println(c + " is greater than " +a + " and " +b);

		/* Using ternary Operator*/
		String s1 = (a>b && a>c ) ?  "Yes" : "No" ; 
		if (s1 == "Yes")
			System.out.println(a + " is greater than " +b + " and " +c);

		String s2 = (b>a && b>c ) ?  "Yes" : "No" ; 
		if (s2 == "Yes")
			System.out.println(b + " is greater than " +a  +" and " +c);

		String s3 = (c>a && c>b ) ?  "Yes" : "No" ; 
		if (s3 == "Yes")
			System.out.println(c + " is greater than " +a + " and " +b);

		



	}
}