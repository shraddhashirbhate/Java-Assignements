import java.util.*;
class Que3{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of X : ");
		int  x = sc.nextInt();
		int y = x*x + 3*x - 7;
		System.out.println("Value of Y is  : " +y);
	
		int y1= x++ + ++x;
		System.out.println("Value of X is : " + x );
		System.out.println("Value of Y is : " + y1 );
		System.out.println("\n");		

		int z = x++ - --y1 - --x + x++;
		System.out.println("Value of X is : " + x );
		System.out.println("Value of Y is : " + y1 );
		System.out.println("Value of Z is : " + z );
		System.out.println("\n");		

		boolean a = true;
		boolean b = false;
		boolean c = a && b || !(a || b);
		System.out.println("Value of X is : " + a);
		System.out.println("Value of Y is : " + b );
		System.out.println("Value of Z is : " + c );

	}

}