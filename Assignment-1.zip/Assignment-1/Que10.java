import java.util.Scanner;
public class Que10{
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter tempearture in Fahrenheit : ");
		float f = sc.nextFloat();
		float celsius = 5*(f-32)/9 ; 
		System.out.println("Temperature in Celsius : " +celsius);
	}
}