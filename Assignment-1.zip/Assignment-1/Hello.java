class Hello{
	public static void main(String args[]){
		System.out.println("HELLO JAVA");
	}
}


/*
	After compilation .class file will be gnerated
	byte code generated will be by the name of class.
	
*/