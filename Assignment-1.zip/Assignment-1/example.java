public class SqrtExample{
public static void main(String [] args){
double value = -9.0;
System.out.println(Math.sqrt(value));
}
} 
