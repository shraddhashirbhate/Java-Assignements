import java.util.Scanner;
class Que11{
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st number : ");
		int a = sc.nextInt();
		
		System.out.println("Enter 2nd number : ");
		int b = sc.nextInt();
		
		System.out.println("Variables before Swap : " +a + "  " +b);
		a = a+b;
		b = a-b;
		a = a-b;

		System.out.println("Variables after Swap : " +a + "  " +b);
		
	}
}