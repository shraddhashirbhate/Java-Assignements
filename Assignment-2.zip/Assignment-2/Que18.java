import java.util.Scanner;
class Que18{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter any number : ");
		int num = sc.nextInt();
		int flag =0 ;

		for(int i=2; i<num/2; i++)
		{
			if(num%1 == 0)
			{
				flag = flag+1;
			}
		}

		if(num == 1)
			System.out.println("1 is neither prime nor composite number ");
			//System.out.println(flag);
		if(flag >=1 )
			System.out.println(num + " is NOT a Prime number");
		else
			System.out.println(num + "is a Prime number");
	}
}