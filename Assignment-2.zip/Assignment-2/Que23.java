import java.util.Scanner;
class Que23{
	
	static void reverse(int a[], int n){
		int b[] = new int[n];
		int j = n;
		for(int i=0; i<n; i++){
			b[j-1] = a[i];
			j--;
		}
		System.out.println("Reversed Array Elements are : ");
		for(int i=0;i<n; i++){
			System.out.println(b[i]);
		}
	}

	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter number of array elements : ");
	int n = sc.nextInt();
	
	System.out.println("Enter Array Elements : ");
	int a[] = new int[n];	

		for(int i=0; i<n; i++) {
			a[i] = sc.nextInt();
		}

		reverse(a, n);
	}
}