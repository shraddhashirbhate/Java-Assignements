import java.util.Scanner;
class Que21 {
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	
	double sum = 0;
	double avg;
	int arr[] = new int[10];
	
		for(int i=0; i<10; i++) {
			System.out.print("Enter " + i + " array Element : ");
			arr[i] = sc.nextInt();
		}
		System.out.println("");	

		for(int a : arr){
			sum += a;
		}
		avg = sum/10;
		System.out.println("Sum of 10 elements is : " +sum); 
		System.out.println("Average of 10 elements is : " +avg);
 
	}
}