/*
29.	Write a program to print the total number of one-D arrays in a two-D array 
	and the number of elements in every one-D array present in the two-D arrays.
*/


import java.util.Scanner;
class Que29{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);

	System.out.println("Enter size of array : ");
	int n = sc.nextInt();
	
	System.out.println("Enter array elements : ");
		for(int i=0; i<n; i++)
		{
			a[i] = sc.nextInt();
		}
		
		System.out.println("1-D Array Elements are : ");
		for(int b : a){
			System.out.println(b);
		}

		for(int i=0; i<n; i++){
			for(int j=0; j<)
		}
	}
}