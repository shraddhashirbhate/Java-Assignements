import java.util.Scanner;
class Que20{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	
	System.out.println("*****Enter Range*****");
	System.out.println("");
	System.out.println("Enter lower limit : ");
	int L = sc.nextInt();
	
	System.out.println("Enter upper limit : ");
	int U = sc.nextInt();

	System.out.println("Prime numbers between " +L +" and  "+ U +" are : ");
	int j, flag = 1;

		for(int i=L; i<= U; i++)
		{
			if(i==0 || i==1 || i==2)
				continue;

			for(j=2; j<i; ++j)
			{
				if(i%j == 0)
				{
					flag=2;
					break;	
				}
			}
			if(j==i)
			flag=1;
			if(flag == 1)
				System.out.println(i);	
				
		}
	}
}