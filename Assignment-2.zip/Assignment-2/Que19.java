import java.util.Scanner;
class Que19{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter range : ");
		int range = sc.nextInt();
		int sum= 0;
		for(int i=1; i<=range; i++)
		{
			sum += i*10 + 2; 
		}	
		System.out.println(sum);
	}
}