import java.util.Scanner;
class Que24{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter size of Array : ");
	int n = sc.nextInt();
		
	int a[] = new int[n];
	
	System.out.println("Enter Elements of array : ");
		for(int i=0; i<n; i++){
			a[i] = sc.nextInt();
		}

	System.out.println("Enter the element to be searched : ");
	int s = sc.nextInt(); 
		for(int i=0; i<n; i++){
			if(a[i]==s)
			{
				System.out.println(s + " is present in the Array ");
				break;
			}	
			System.out.println(s + " is not present in the Array ");
		}
		
		System.out.println(s + " is not present in the Array ");
	}
}