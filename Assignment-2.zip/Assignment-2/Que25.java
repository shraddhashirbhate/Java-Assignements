import java.util.Scanner;
class Que25{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of Array : ");
	int n = sc.nextInt();
	
	int a[] = new int[n];
	int sumE=0, sumO=0;

	System.out.println("Enter the elements of array : ");
		for(int i=0; i<n; i++)
		{
			a[i] = sc.nextInt();
		}
		
		for(int i=0; i<n; i++){
			if(a[i]%2==0)
				sumE += a[i];
			else
				sumO += a[i];
		}
		System.out.println("Sum of EVEN array elements are : " +sumE);
		System.out.println("Sum of ODD array elements are : " +sumO);
	}
}