/*
33.	Write a program to demonstrate functionalities of this keyword in java. 
*/


class Que33Student{
	private int Id;
	private String name;
	private int marks;
	
	Que33Student(int Id, String name, int marks){
		this.Id = Id;
		this.name = name;
		this.marks=marks;
	}

	void show()
	{
		System.out.println(Id + " " +name + " " + marks);
	}
}

class Que33{
	public static void main(String args[]){
		Que33Student s = new Que33Student(108, "Shraddha", 45);
		s.show();
		Que33Student s1 = new Que33Student(94, "Ruapli", 54);	
		s1.show();
	}
	

}