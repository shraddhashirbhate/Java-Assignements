/*
41.	Write a program to demonstrate this() construct functionality.
*/

class Que41Student{
	private int rollNo;
	private String name;
	
	Que41Student() {
		this(108,"Shraddha");
		System.out.println("0-parameter");
	}	

	Que41Student(int rollNo, String name){
		this.rollNo = rollNo;
		this.name = name;
		System.out.println("2-Parameter");
		System.out.println(rollNo + " " +name);
	}
	
}

class Que41{
	public static void main(String args[]){
	Que41Student s = new Que41Student();
	
	}
}