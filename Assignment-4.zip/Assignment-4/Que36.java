/*
36.	Create a class MathOperation containing overloaded methods 
	‘multiply’ to calculate multiplication of following arguments. 
	a. two integers 
	b. three floats 
	c. all elements of array 
	d.one double and one integer 
*/
import java.util.Scanner;
class Que36MathOp{
	private int w,x;
	private int s;
	private float i,j,k;
	//int a[] = new int[s];
	double d;
	
	/*
	Que36MathOp( int s){
		this.s = s;
	}*/	

	Que36MathOp(int w, int x){
		this.w = w;
		this.x = x;
	}
	
	Que36MathOp(float i, float j, float k){
		this.i = i;
		this.j = j;
		this.k = k;
	}
	
	Que36MathOp(int w, double d){
		this.w = w;
 		this.d = d;
	}

	void multiply(int w, int x){
		int mul = w*x;
		System.out.println("Multiplication of two integer numbers is : " +mul);
	}

	void multiply(float i, float j, float k){
		float mul = i*j*k;
		System.out.println("Multiplication of three float numbers is : " +mul);
	}

	void multiply(int w, double d){
		double mul = w*d;
		System.out.println("Multiplication of  one integer and one double is : " +mul);
	}

	/*
	void multiply(int a[], int s){
		int mul=1;
		for(int i; i<s; i++){
			mul *= a[i];
		}
		System.out.println("Multiplication of all Array Elements is : " +mul); 
	} */
	
}

class Que36{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);

	/*
	System.out.println("Enter size of array : ");
	int s = sc.nextInt();
	int a[] = new a[s];
	
	System.ou.println("Enter array Elements : ");
	for(int i=0; i<s; i++)	{
		a[i] = sc.nextInt();
	}*/

	System.out.println("Enter two integer numbers : ");
	int a = sc.nextInt();
	int b = sc.nextInt();

	System.out.println("Enter three float numbers : ");
	float c = sc.nextFloat();
	float d = sc.nextFloat();
	float e = sc.nextFloat();

	System.out.println("Enter one double number : ");
	double d1 = sc.nextDouble();
	
	Que36MathOp op = new Que36MathOp(a, b);
	op.multiply(a,b);

	Que36MathOp op1 = new Que36MathOp(c, d, e);
	op1.multiply(c, d, e);

	Que36MathOp op2 = new Que36MathOp(a, d1);
	op2.multiply(a,d1);

	/*
	Que36MathOp op3 = new Que36MathOp(a[], s);
	Op3.multiply(a[], s); */

	}
}





