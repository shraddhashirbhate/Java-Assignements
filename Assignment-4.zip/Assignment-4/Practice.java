/*
public class Practice{
	public Practice(String s){
		System.out.println("Practice");
	}
}

class B extends Practice{
	public B(String s){
		System.out.println("B");		
	}

	public static void main(String[] args){
		new B("C");

		System.out.println(" ");
	}
}*/

/*
class Practice 
{

}
class Y{

}
class Z extends Practice, Y{}

*/

/*
public class Practice{
	public static void gfg(String s){
		System.out.println("String");
	}
	
	public static void gfg(Object o){
		System.out.println("Object");
	}
	
	public static void main(String args[]){
		gfg(null);
	}
}

*/

/*
class A{
	int i = 10;
	public A(int j )
	{
		System.out.println(i);
		this.i = j*10;
	}
}
class B extends A{
	
	public B (int j )
	{
		super(j);
		System.out.println(i);
		this.i = j*20;
	}
}
public class Practice{

	public static void main(String args[]){
		B n = new B(20);
		System.out.println(n.i);
	}
}

*/

/*
class Base{
	protected void foo() {}
}
class B extends Base{
	void foo() {}
}
public class Practice{
	public static void main(String args[]){
		B d= new B();
		d.foo();
	}
}
*/

class A{
	public A() {
	System.out.println("a");
	}
}
class B extends A{
	public B() {
	System.out.println("b");
	}
}
class C extends B{
	public C() {
	System.out.println("c");
	}
}

public class Practice{
	public static void main(String args[]){
		C c = new C();
		
	}
}














