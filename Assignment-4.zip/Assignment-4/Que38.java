/*
38.	Create a class Employee with three data members 
	(empNo, salary and totalSalary) and following features.
	a.Only parameterized constructor. [Do not overload the constructor]
	b.totalSalary always represents salary total of all the employees created.
	c.empNo should be auto incremented.
	d.display total employees and totalSalary using a method.
	
	Create another class EmployeeDemo (main class) that creates some 
	Employee objects and calls Employee method to display no. of employees 
	and total of their salaries.
*/

class EmployeeQue38{
	private static int empNo;
	private double salary;
	private static float totalSalary;

	EmployeeQue38(double salary){
		empNo++;
		this.salary = salary;
		totalSalary += salary;
	}

	void display(){
		System.out.println("Total no. of Employees are : "+empNo);
		System.out.println("Total Salary of the Employees are : " +totalSalary);	
	}	
}
class Que38{
	public static void main(String args[]){
		EmployeeQue38 e = new EmployeeQue38 (5000.7);
		EmployeeQue38  e1= new EmployeeQue38 (5000);
		EmployeeQue38  e2 = new EmployeeQue38 (5000);
		e2.display();
		System.out.println("--------------------------------------------");
		EmployeeQue38   e3=new EmployeeQue38  (5000);
		e3.display();

	}

}

