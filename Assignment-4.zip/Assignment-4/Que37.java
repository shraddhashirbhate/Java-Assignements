/*
37.	Create a class Person with properties (name and age) with following features. 
	a.Default age of person should be 18.
	b.A person object can be initialized with name and age.
	c.Method to display name and age of person
	Create another class PersonDemo ( main class ) that demonstrates the 
	functionalities of Person class by creating Person object and calling methods.
*/

class Que37Person{
	private String  name;
	private int age;

	Que37Person (){
		name = "Ananya Pandey";
		age = 18;		
	}

	Que37Person(String name, int age){
		this.name = name;
		this.age = age;
	}
	
	void display(){
		System.out.println("Name of the Person is : " +name);	
		System.out.println("Age of the Person is : " +age) ;
	}
}

public class Que37{
	public static void main(String[] args)
	{
		Que37Person p = new Que37Person();
		p.display();

		Que37Person p1 = new Que37Person("Kartika Aryan", 27);
		p1.display();
	}
}