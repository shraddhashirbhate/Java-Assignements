/*
35.	Create a class MathOperation that has four static methods. 	
	1)	add() method that takes two integer numbers as parameter 
		and returns the sum of the numbers. 
	2)	subtract() method that takes two integer numbers as parameter 
		and returns the difference of the numbers. 
	3)	multiply() method that takes two integer numbers as parameter 
		and returns the product. 
	4)	power() method that takes two integer numbers as parameter 
		and returns the power of first number to second number. 

	Create another class Demo (main class) that takes the two numbers 
	from the user and calls all four methods of MathOperation class by 
	providing entered numbers and prints the return values of every method.
*/
import java.util.Scanner;
class Que35MathOpe{
	private int x;
	private int y;

	Que35MathOpe(int x, int y){
		this.x = x;
		this.y = y;
	}

	static int add(int x, int y){
		return x + y;
	}

	static int sub(int x, int y){
		
		return x - y;
	}

	static int multiply(int x, int y){
		return x * y;
	}

	static double power(int x, int y){
		double p = Math.pow(x,y);
		return p;
	}
}

class Que35{
	public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);

	System.out.println("Enter 1st number : ");
	int a = sc.nextInt();

	System.out.println("Enter 2nd number : ");
	int b = sc.nextInt();

	Que35MathOpe op = new Que35MathOpe(a,b);
	int add = op.add(a,b);
	System.out.println("Addition is : " +add);

	Que35MathOpe op1 = new Que35MathOpe(a,b);
	int sub = op1.sub(a,b);
	System.out.println("Subtraction is : " +sub);

	Que35MathOpe op2 = new Que35MathOpe(a,b);
	int mul = op2.multiply(a,b);
	System.out.println("Multiplcation is : " +mul);

	Que35MathOpe op3 = new Que35MathOpe(a,b);
	double pow = op3.power(a,b);
	System.out.println("Power is : " +pow); 
	
	}
	
}