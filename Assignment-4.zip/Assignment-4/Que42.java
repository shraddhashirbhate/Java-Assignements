/*
42.	Create a class Tile to store the edge length of a square tile, 	
	and create another class Floor to store length and width of a 
	rectangular floor. 
	Add method totalTiles(Tile t) in Floor class with Tile 
	as argument to calculate the whole number of tiles needed to 	
	cover the floor completely.
*/

import java.util.Scanner;
class Que42Tile{
	private double edgeLength;	
	private double area;
		
	Que42Tile(double edgeLength){
		this.edgeLength = edgeLength;
		area = edgeLength*edgeLength;
	} 

/*
	int Area(int edgeLength){
		return edgeLength*edgeLength;
	}
*/
}

class Floor{
	private double length;
	private double width;
	private double fArea;


	Floor(double  length, double  width){
		this.length = length;
		this.width = width;
		fArea = length * width;
	}

	double totalTiles(Que42Tile t){
		//double A = t.Area();
		double noOfTiles = fArea/t.A;	
		return noOfTiles ;
	}
}

class Que42{
	public static void main(String args[]){
		//Floor f = new Floor();
		Scanner sc = new Scanner(System.in);	 
	    Que42Tile t = new Que42Tile(10);
	    Floor f = new Floor(100, 500);
	    System.out.println("Total no of tiles required : "+f.totalTiles(t));
	}
}