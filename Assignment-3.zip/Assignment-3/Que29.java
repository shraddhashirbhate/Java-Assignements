/*
29.	Write a program to print the total number of one-D arrays in a two-D array 
	and the number of elements in every one-D array present in the two-D arrays.
*/


public class Que29 {

	public static void main(String[] args) {
		int a[] = {1,2,4,6};
		int b[] = {7,9,2,3,};
		int c[] = {8,9,2,3,4,8};
		
		int arr[][] = new int[3][];
		arr[0] =a;
		arr[1]=b;
		arr[2]=c;
		
		int countA = 0;
		
		
		for(int ar[] : arr) {
			countA++;
			int countB = 0;
			for(int e : ar) {
				countB++;
				
			}
			System.out.println("Total number of elemnts in 1D array are :  "+countB);
		}
		System.out.println("Total number of 1D arrays are : "+countA);

	}

}