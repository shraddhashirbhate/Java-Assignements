import java.util.Scanner;
class Que27{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter the size of Array : ");
	int n = sc.nextInt();
		
	int a[] = new int[n];
	
	System.out.println("Enter Array Elements : ");
		for(int i=0; i<n; i++){
			a[i] = sc.nextInt();
		}

		int small = a[0];
		int max = a[0];

		for(int i=1; i<n; i++){
			if(a[i] < small) 
				small = a[i];
		}

		for(int i=1; i<n; i++){
			if(a[i] > max) 
				max = a[i];
		}

		System.out.println("Smallest Elements present in the array is : " +small);
		System.out.println("Greatest Elements present in the array is : " +max);

	}
}













