/*
31.	Create a class Student with 2 data members rno and name. 
	Create one method setData() that takes roll number and student name as 
	parameter and stores them in data members rno and name. 
	Create one more method showData() to print the data member values. 
	Create another class ( main class) StudentDemo that creates Student class 
	object and calls setData() and showData() methods.

*/

class Student{
	private int rno;
	private String Name;


	void setData(int RN, String n){
		rno = RN;
		Name = n;
	}

	void showData(){
		System.out.println(rno + "  " +Name);
	}
}
class StudentDemo{
	public static void main(String args[]){
		Student s1 = new Student();
		s1.setData(1, " Shraddha Shirbhate");
		s1.showData();
	}
}


/*
	Note:	compile :  javac Que31.java
		run        :  java StudentDemo
*/