import java.util.Scanner;
class Que28{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
		
	System.out.println("Enter size of array :  ");
	int n = sc.nextInt();
	
	String s[] = new String[n];
		System.out.println("Enter Array Elements : ");
		for(int i=0; i<n; i++){
			s[i] = sc.nextLine();
		}
		
		System.out.println("Elements in the array are : ");
		for(String a : s)
		{
			System.out.println(a);
		}
	}
}