/*
32.	Modify the above program (no. 30) to count the no of Student 
	objects created. [ In this program static variable is required ]
*/

class Student{
	private int rno;
	private String Name;
	public static int count;


	void setData(int RN, String n, int c){
		rno = RN;
		Name = n;
		count = c;
	}

	void showData(){
		System.out.println(rno + "  " +Name+ "  "+count);
		System.out.println(" No of Student objects created are : " +count);
	}
}
class StudentDemo{
	public static void main(String args[]){
		Student s1 = new Student();
		s1.setData(1, " Shraddha Shirbhate", 1);
		s1.showData();
		
		Student s2 = new Student();
		s2.setData(2, " Rupali Pangare", 2);
		s2.showData();

		Student s3 = new Student();
		s3.setData(3, " Sandhya Pandey", 3);
		s3.showData();

		
		
	}
}