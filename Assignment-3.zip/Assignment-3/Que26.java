/* 26.	Create an array of 17 elements in 5 rows.  And calculate sum of all elements.*/

import java.util.Scanner;
class Que26{
	public static void main(String srgs[]){
	Scanner sc = new Scanner(System.in);	

		System.out.println("Enter number of Rows : ");
		int r = sc.nextInt();
	
		int a[][] = new int[r][];
		
		for(int i=0; i<a.length; i++){
			System.out.println("Enter number of COlumns for " +(i+1) +"th Row");
			int c = sc.nextInt();
			a[i] = new int[c];
			for(int j=0; j<a[i].length; j++){
				a[i][j] = sc.nextInt();
			} 
		}

		int Sum = 0;
		System.out.println("Array Elements are :  ");
		for(int arr[] : a ){
			for(int b : arr){
				System.out.print("    "+b);
				Sum+=b;
			}
		System.out.println("");
		}
		System.out.println("Sum of Array Elements are : " +Sum);
	}
}