/*
30.	Create an integer type 2-D array of size [3X3]. Take the elements from 
	the user and then calculate the sum of the elements present in the diagonal.
*/

import java.util.Scanner;
class Que30{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);

	int a[][] = new int[3][3];
	int Sum=0;

	System.out.println("Enter the elements of array : ");
		for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++)
			{
				a[i][j] = sc.nextInt();
			}
		}

	System.out.println("Array Elements are : ");
		for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++)
			{
				System.out.print("  " + a[i][j] + "  ");
			}
			System.out.println("");
		}

	System.out.println("Sum of Diagonal Elements are : ");
		for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++)
			{
				if(i==j)
				{
					Sum+= a[i][j];
				}	
			}		
		}	
		System.out.print(Sum);
		
	}
}